client_id = ''
client_secret = ''

# usernames and/or subreddits to keep an eye on.
usernames = ['diceroll123']
subreddits = ['android', 'science', 'technology', 'unixporn']
